package com.example.deepakassignment.database

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(entities = [StudentDetails::class], version = 1)
abstract class StudentsDatabase : RoomDatabase() {
    abstract fun getStudentDetailsDao(): StudentDetailsDao

    companion object {
        private lateinit var databaseInstance: StudentsDatabase
        fun getStudentDatabase(context: Context): StudentsDatabase {
            if (::databaseInstance.isInitialized.not()) {
                databaseInstance = Room.databaseBuilder(
                    context.applicationContext,
                    StudentsDatabase::class.java, "students-database"
                ).build()
            }
            return databaseInstance
        }
    }
}