package com.example.deepakassignment.view

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.ExpandableListView
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import com.example.deepakassignment.R
import com.example.deepakassignment.database.StudentDetails
import com.example.deepakassignment.database.StudentsDatabase
import com.example.deepakassignment.repository.MainRepository
import com.example.deepakassignment.viewmodel.MainViewModel
import com.example.deepakassignment.viewmodel.MainViewModelFactory

class MainActivity : AppCompatActivity() {
    private val databaseInstance: StudentsDatabase by lazy {
        StudentsDatabase.getStudentDatabase(applicationContext)
    }
    private val mainViewModelFactory: MainViewModelFactory by lazy {
        MainViewModelFactory(MainRepository(databaseInstance))
    }
    private val mainViewModel: MainViewModel by lazy {
        ViewModelProvider(this, mainViewModelFactory)[MainViewModel::class.java]
    }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        val studentsExpandableListView = findViewById<ExpandableListView>(R.id.student_list_elv)
        mainViewModel.getStudentDetail().observe(this, Observer { studentsList ->
            if (studentsList.isNullOrEmpty().not()) {
                val listOfToppers = studentsList.map { it.value.first() }
                val adapter = StudentELVAdapter(listOfToppers, studentsList) { deletedItem ->
                    mainViewModel.deleteStudent(deletedItem)
                }
                studentsExpandableListView.setAdapter(adapter)
            }
        })
    }
}