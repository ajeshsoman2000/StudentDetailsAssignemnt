package com.example.deepakassignment.database

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey
import com.google.gson.annotations.SerializedName

@Entity(tableName = "student_details_table")
data class StudentDetails(
    @ColumnInfo(name = "marks")
    val marks: Int,
    @PrimaryKey
    @ColumnInfo(name = "roll_number")
    @SerializedName("roll_number")
    val rollNumber: String,
    @ColumnInfo(name = "class")
    @SerializedName("class")
    val className: String,
    @ColumnInfo(name = "first_name")
    @SerializedName("first_name")
    var firstName: String,
    @ColumnInfo(name = "last_name")
    @SerializedName("last_name")
    val lastName: String
)
