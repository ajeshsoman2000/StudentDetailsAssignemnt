package com.example.deepakassignment.repository

import android.content.Context
import android.util.Log
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import com.example.deepakassignment.R
import com.example.deepakassignment.database.StudentDetails
import com.example.deepakassignment.database.StudentsDatabase
import com.google.gson.Gson
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.*
import java.util.*
import kotlin.collections.HashMap

class MainRepository(private val database: StudentsDatabase) {

    fun getStudentDetails(): LiveData<HashMap<String, List<StudentDetails>>> {
        val mutableStudentsLiveData = MutableLiveData<HashMap<String, List<StudentDetails>>>()
        val temp = database.getStudentDetailsDao().getStudentDetails()
        temp.observeForever {
            if (it.isNullOrEmpty().not()) {
                mutableStudentsLiveData.postValue(filteringLogic(it))
            }
        }
        return mutableStudentsLiveData
    }

    fun getAllStudentDetails() = database.getStudentDetailsDao().getAllClasses()


    suspend fun readStudentDetailsFromFile(context: Context) {
        val inputStream: InputStream = context.resources.openRawResource(context.resources.getIdentifier("response",
                "raw", context.packageName
        ));
        val writer: Writer = StringWriter()
        val buffer = CharArray(1024)
        try {
            val reader: Reader = BufferedReader(InputStreamReader(inputStream, "UTF-8"))
            var n: Int
            while (reader.read(buffer).also { n = it } != -1) {
                writer.write(buffer, 0, n)
            }
            inputStream.close()
        } catch (ex: Exception) {
        }
        val jsonString = writer.toString()
        val gson = Gson()
        val studentData: Array<StudentDetails> = gson.fromJson<Array<StudentDetails>>(
            jsonString,
            Array<StudentDetails>::class.java
        )
        insertStudentDetailsIntoDB(studentData.toList())
    }

    private suspend fun insertStudentDetailsIntoDB(students: List<StudentDetails>) {
        students.forEach {
            database.getStudentDetailsDao().insertStudent(it)
        }
    }

    private fun filteringLogic(students: List<StudentDetails>): HashMap<String, List<StudentDetails>> {
        val classes = students.map { it.className }.toHashSet()
        val studentsHashMap = HashMap<String, List<StudentDetails>>()
        classes.forEach { className ->
            studentsHashMap[className] = students.filter { it.className == className }.sortedByDescending { it.marks }
        }
        return studentsHashMap
    }

    suspend fun deleteStudent(student: StudentDetails) {
        database.getStudentDetailsDao().deleteStudent(student)
    }
}