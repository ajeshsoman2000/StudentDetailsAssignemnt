package com.example.deepakassignment.view

import android.content.Context
import android.graphics.Typeface
import android.os.Build
import android.text.Html
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.BaseExpandableListAdapter
import android.widget.ImageButton
import android.widget.TextView
import androidx.annotation.RequiresApi
import com.example.deepakassignment.R
import com.example.deepakassignment.database.StudentDetails
import kotlin.math.exp

class StudentELVAdapter(val toppersList: List<StudentDetails>,
                        val studentsList: HashMap<String, List<StudentDetails>>,
                        val deleteListener: (StudentDetails) -> Unit): BaseExpandableListAdapter() {
    override fun getGroupCount(): Int {
        return toppersList.size
    }

    override fun getChildrenCount(p0: Int): Int {
        return studentsList[toppersList[p0].className]?.size ?: 0
    }

    override fun getGroup(p0: Int): Any {
        return toppersList[p0]
    }

    override fun getChild(listPosition: Int, expandPosition: Int): Any {
        return studentsList[toppersList[listPosition].className]!![expandPosition]
    }

    override fun getGroupId(listPosition: Int): Long {
        return listPosition.toLong()
    }

    override fun getChildId(listPosition: Int, expandPosition: Int): Long {
        return expandPosition.toLong()
    }

    override fun hasStableIds(): Boolean {
        return false
    }

    override fun getGroupView(position: Int, isExpanded: Boolean, view: View?, viewGroup: ViewGroup?): View {

        //check for re-using view
        var convertView = view
        if (convertView == null) {
            convertView = (viewGroup?.context?.getSystemService(Context.LAYOUT_INFLATER_SERVICE) as LayoutInflater)
                .inflate(R.layout.student_el_header_item, null)
        }

        val nameTv: TextView = convertView?.findViewById(R.id.name_tv)!!
        val rollNoTv: TextView = convertView.findViewById(R.id.roll_no_tv)
        nameTv.setTypeface(null, Typeface.BOLD)
        rollNoTv.setTypeface(null, Typeface.BOLD)
        val item: StudentDetails = toppersList[position]
        nameTv.text = item.firstName.toString() + " " + item.lastName
        rollNoTv.text = item.rollNumber
        return convertView
    }

    @RequiresApi(Build.VERSION_CODES.N)
    override fun getChildView(listPosition: Int, expandPosition: Int, isExpanded: Boolean, view: View?, viewGroup: ViewGroup?): View {
        val tag: ViewHolderItem = ViewHolderItem()
        var convertView = view
        tag.groupPosition = listPosition
        tag.childPosition = expandPosition
        if (convertView == null) {
            convertView = (viewGroup?.context?.getSystemService(Context.LAYOUT_INFLATER_SERVICE) as LayoutInflater)
                .inflate(R.layout.student_el_child_item, null)
        }
        val item: StudentDetails =
            studentsList[toppersList[listPosition].className]?.get(expandPosition)!!
        val rollNoTv: TextView = convertView?.findViewById(R.id.el_child_roll_no_tv)!!
        val text = Html.fromHtml(
            "<b>" + view?.context?.resources?.getString(R.string.roll_number_text) + "</b>" + item.rollNumber,
            Html.FROM_HTML_MODE_COMPACT
        )
        rollNoTv.text = text
        val deleteBtn: ImageButton = convertView.findViewById<ImageButton>(R.id.child_delete_btn)
        deleteBtn.tag = tag
        Log.d("getChildView", "marks " + item.marks)
        deleteBtn.setOnClickListener { deleteListener(item) }
        return convertView
    }

    override fun isChildSelectable(p0: Int, p1: Int): Boolean {
        return true
    }

    /**
     * ViewHolger class to set tag
     */
    internal class ViewHolderItem {
        var groupPosition = 0
        var childPosition = 0
    }
}