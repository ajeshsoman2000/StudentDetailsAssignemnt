package com.example.deepakassignment.viewmodel

import android.content.Context
import android.util.Log
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.example.deepakassignment.database.StudentDetails
import com.example.deepakassignment.repository.MainRepository
import com.example.deepakassignment.view.MainActivity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class MainViewModel(private val repository: MainRepository): ViewModel() {

    private val coroutineScope = CoroutineScope(Dispatchers.IO)
    private val studentDetailsLiveData = MutableLiveData<HashMap<String, List<StudentDetails>>>()

    fun getStudentDetail(): LiveData<HashMap<String, List<StudentDetails>>> {
        repository.getStudentDetails().observeForever {studentsList ->
            studentDetailsLiveData.postValue(studentsList)
        }
        return studentDetailsLiveData
    }

    fun insertStudentDetailsToDB(context: Context) {
        coroutineScope.launch {
            repository.readStudentDetailsFromFile(context)
        }
    }

    fun getAllClasses() = repository.getAllStudentDetails()

    fun deleteStudent(student: StudentDetails) {
        coroutineScope.launch { repository.deleteStudent(student) }
    }
}