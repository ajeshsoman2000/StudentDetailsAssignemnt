package com.example.deepakassignment.view

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ProgressBar
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import com.example.deepakassignment.R
import com.example.deepakassignment.database.StudentsDatabase
import com.example.deepakassignment.repository.MainRepository
import com.example.deepakassignment.viewmodel.MainViewModel
import com.example.deepakassignment.viewmodel.MainViewModelFactory

class SplashScreenActivity : AppCompatActivity() {
    private val databaseInstance: StudentsDatabase by lazy {
        StudentsDatabase.getStudentDatabase(applicationContext)
    }
    private val mainViewModelFactory: MainViewModelFactory by lazy {
        MainViewModelFactory(MainRepository(databaseInstance))
    }
    private val mainViewModel: MainViewModel by lazy {
        ViewModelProvider(this, mainViewModelFactory)[MainViewModel::class.java]
    }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_splash_screen)
        mainViewModel.getAllClasses().observe(this, Observer { classesList ->
            if (classesList.isNullOrEmpty()) {
                mainViewModel.insertStudentDetailsToDB(this@SplashScreenActivity)
                startActivity(Intent(this@SplashScreenActivity, MainActivity::class.java))
            } else {
                startActivity(Intent(this@SplashScreenActivity, MainActivity::class.java))
            }
            finish()
        })
    }
}