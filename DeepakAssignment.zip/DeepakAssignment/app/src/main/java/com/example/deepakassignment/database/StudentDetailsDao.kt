package com.example.deepakassignment.database

import androidx.lifecycle.LiveData
import androidx.room.*

@Dao
interface StudentDetailsDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertStudent(student: StudentDetails)

    @Query("SELECT * FROM student_details_table")
    fun getStudentDetails(): LiveData<List<StudentDetails>>

    @Query("SELECT class FROM student_details_table")
    fun getAllClasses(): LiveData<List<String>>

    @Delete
    suspend fun deleteStudent(student: StudentDetails)
}